import pygame
import random

pygame.init()

# Configurações da tela
LARGURA = 800
ALTURA = 600
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Flappy Bird - Analise de Processos")

clock = pygame.time.Clock()

# Cores
AZUL = (135, 206, 235)
VERDE = (34, 139, 34)
AMARELO = (255, 220, 0)
BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)

# Passaro
passaro_x = 150
passaro_y = 300
velocidade = 0
gravidade = 0.5
pulo = -9

# Cano
cano_largura = 80
cano_velocidade = 4
espaco = 180

cano_x = LARGURA
cano_altura = random.randint(100, 350)

# Pontuacao
pontos = 0
fonte = pygame.font.SysFont(None, 40)

rodando = True

while rodando:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            rodando = False

        if evento.type == pygame.KEYDOWN:
            if evento.key == pygame.K_SPACE:
                velocidade = pulo

    # Gravidade
    velocidade += gravidade
    passaro_y += velocidade

    # Movimento do cano
    cano_x -= cano_velocidade

    # Cria outro cano quando o primeiro sai da tela
    if cano_x < -cano_largura:
        cano_x = LARGURA
        cano_altura = random.randint(100, 350)
        pontos += 1

    # Colisoes
    passaro = pygame.Rect(passaro_x, passaro_y, 40, 30)

    cano_cima = pygame.Rect(
        cano_x,
        0,
        cano_largura,
        cano_altura
    )

    cano_baixo = pygame.Rect(
        cano_x,
        cano_altura + espaco,
        cano_largura,
        ALTURA
    )

    if passaro.colliderect(cano_cima) or passaro.colliderect(cano_baixo):
        passaro_y = 300
        velocidade = 0

    # Limites da tela
    if passaro_y < 0:
        passaro_y = 0
        velocidade = 0

    if passaro_y > ALTURA - 30:
        passaro_y = ALTURA - 30
        velocidade = 0

    # Desenho
    tela.fill(AZUL)

    pygame.draw.rect(
        tela,
        VERDE,
        cano_cima
    )

    pygame.draw.rect(
        tela,
        VERDE,
        cano_baixo
    )

    pygame.draw.rect(
        tela,
        AMARELO,
        passaro
    )

    texto = fonte.render(
        f"Pontos: {pontos}",
        True,
        BRANCO
    )

    tela.blit(texto, (20, 20))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()